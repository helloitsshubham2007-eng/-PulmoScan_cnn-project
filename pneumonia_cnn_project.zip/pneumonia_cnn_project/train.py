"""
train.py
========
End-to-end training + evaluation for the pneumonia CNN project.

Usage:
    python train.py                     # runs on the built-in synthetic demo dataset
    python train.py --data_dir chest_xray   # runs on the real Kaggle dataset

Outputs (written to ./outputs/):
    training_curves.png   - accuracy & loss vs. epoch
    confusion_matrix.png
    roc_curve.png
    sample_predictions.png
    metrics.json           - final numeric results used in the report
    pneumonia_cnn.keras    - trained model weights
"""

import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from sklearn.metrics import (confusion_matrix, roc_curve, auc,
                              classification_report)

from dataset import generate_synthetic_dataset, load_real_dataset
from model import build_cnn

OUT_DIR = "outputs"


def plot_training_curves(history, out_path):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(history.history["accuracy"], label="train")
    axes[0].plot(history.history["val_accuracy"], label="val")
    axes[0].set_title("Accuracy")
    axes[0].set_xlabel("Epoch")
    axes[0].legend()

    axes[1].plot(history.history["loss"], label="train")
    axes[1].plot(history.history["val_loss"], label="val")
    axes[1].set_title("Loss")
    axes[1].set_xlabel("Epoch")
    axes[1].legend()

    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_confusion_matrix(cm, class_names, out_path):
    fig, ax = plt.subplots(figsize=(4.5, 4))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(class_names)))
    ax.set_yticks(range(len(class_names)))
    ax.set_xticklabels(class_names)
    ax.set_yticklabels(class_names)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                     color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.colorbar(im)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_roc(y_true, y_prob, out_path):
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    roc_auc = auc(fpr, tpr)
    fig, ax = plt.subplots(figsize=(5, 4.5))
    ax.plot(fpr, tpr, label=f"AUC = {roc_auc:.3f}")
    ax.plot([0, 1], [0, 1], linestyle="--", color="gray")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curve")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return roc_auc


def plot_sample_predictions(x, y_true, y_pred, class_names, out_path, n=8):
    fig, axes = plt.subplots(2, 4, figsize=(11, 5.5))
    idx = np.random.default_rng(0).choice(len(x), size=n, replace=False)
    for ax, i in zip(axes.ravel(), idx):
        ax.imshow(x[i].squeeze(), cmap="gray")
        true_l = class_names[int(y_true[i])]
        pred_l = class_names[int(y_pred[i])]
        color = "green" if true_l == pred_l else "red"
        ax.set_title(f"T:{true_l}\nP:{pred_l}", color=color, fontsize=9)
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def main(data_dir, epochs):
    os.makedirs(OUT_DIR, exist_ok=True)

    if data_dir and os.path.isdir(data_dir):
        print(f"Loading real dataset from {data_dir}")
        train_ds, val_ds, test_ds, class_names, raw_test = load_real_dataset(data_dir)
    else:
        print("No real dataset found -> using synthetic demo dataset "
              "(swap in the real Kaggle dataset with --data_dir).")
        train_ds, val_ds, test_ds, class_names, raw_test = generate_synthetic_dataset()

    model = build_cnn()
    model.summary()

    callbacks = [
        tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=8,
                                          restore_best_weights=True),
        tf.keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5,
                                              patience=4, min_lr=1e-5),
    ]

    history = model.fit(train_ds, validation_data=val_ds, epochs=epochs,
                         callbacks=callbacks, verbose=2)

    plot_training_curves(history, f"{OUT_DIR}/training_curves.png")

    # Gather test set predictions
    if raw_test is not None:
        x_test, y_test = raw_test
    else:
        x_test, y_test = [], []
        for xb, yb in test_ds:
            x_test.append(xb.numpy())
            y_test.append(yb.numpy())
        x_test = np.concatenate(x_test)
        y_test = np.concatenate(y_test).squeeze()

    y_prob = model.predict(x_test, verbose=0).squeeze()
    y_pred = (y_prob >= 0.5).astype(int)

    cm = confusion_matrix(y_test, y_pred)
    plot_confusion_matrix(cm, class_names, f"{OUT_DIR}/confusion_matrix.png")
    roc_auc = plot_roc(y_test, y_prob, f"{OUT_DIR}/roc_curve.png")
    plot_sample_predictions(x_test, y_test, y_pred, class_names,
                             f"{OUT_DIR}/sample_predictions.png")

    report = classification_report(y_test, y_pred, target_names=class_names,
                                    output_dict=True)
    test_loss, test_acc, test_auc = model.evaluate(test_ds, verbose=0) if raw_test is None else \
        model.evaluate(x_test, y_test, verbose=0)

    metrics = {
        "test_accuracy": float(test_acc),
        "test_auc": float(test_auc),
        "roc_auc_sklearn": float(roc_auc),
        "test_loss": float(test_loss),
        "precision_pneumonia": report["PNEUMONIA"]["precision"],
        "recall_pneumonia": report["PNEUMONIA"]["recall"],
        "f1_pneumonia": report["PNEUMONIA"]["f1-score"],
        "confusion_matrix": cm.tolist(),
        "epochs_trained": len(history.history["loss"]),
        "total_params": int(model.count_params()),
        "dataset_mode": "real" if (data_dir and os.path.isdir(data_dir)) else "synthetic_demo",
    }
    with open(f"{OUT_DIR}/metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    model.save(f"{OUT_DIR}/pneumonia_cnn.keras")

    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", default=None,
                         help="Path to Kaggle chest_xray folder (train/val/test). "
                              "If omitted or missing, a synthetic demo dataset is used.")
    parser.add_argument("--epochs", type=int, default=25)
    args = parser.parse_args()
    main(args.data_dir, args.epochs)
