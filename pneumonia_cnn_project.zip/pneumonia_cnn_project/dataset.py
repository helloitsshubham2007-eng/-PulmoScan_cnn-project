"""
dataset.py
==========
Data loading for the Pneumonia Chest X-Ray CNN project.

Two modes are provided:

1. load_real_dataset(data_dir)
   Use this on your own machine after downloading the real Kaggle dataset:
   "Chest X-Ray Images (Pneumonia)" by Paul Mooney
   https://www.kaggle.com/datasets/paultimothymooney/chest-xray-pneumonia
   Expected folder layout (this is exactly how the Kaggle zip is structured):
       data_dir/train/NORMAL/*.jpeg
       data_dir/train/PNEUMONIA/*.jpeg
       data_dir/val/NORMAL/*.jpeg
       data_dir/val/PNEUMONIA/*.jpeg
       data_dir/test/NORMAL/*.jpeg
       data_dir/test/PNEUMONIA/*.jpeg

2. generate_synthetic_dataset(...)
   Used automatically when data_dir does not exist / is not passed.
   Produces procedurally generated grayscale images that mimic the
   *statistical* difference between a clear chest X-ray (NORMAL) and one
   with pneumonia opacity (bright, cloud-like consolidation patches).
   This lets the full pipeline (training, evaluation, report figures) run
   completely offline with no internet/Kaggle account, so you can verify
   the code works before plugging in the real dataset. Swap it out by
   calling load_real_dataset() once you have downloaded the Kaggle data.
"""

import numpy as np
import tensorflow as tf

IMG_SIZE = 64  # 64x64 grayscale — small enough to train fast on CPU


def _make_normal_image(rng, size=IMG_SIZE):
    """Clear lung field: smooth radial vignette + mild texture, low opacity."""
    yy, xx = np.mgrid[0:size, 0:size]
    cy, cx = size / 2 + rng.uniform(-3, 3), size / 2 + rng.uniform(-3, 3)
    r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2) / (size / 2)
    brightness = rng.uniform(0.48, 0.62)
    base = brightness - 0.25 * r
    texture = rng.normal(0, 0.06, size=(size, size))
    ribs = 0.04 * np.sin(yy / rng.uniform(2.6, 3.8) + rng.uniform(0, 3.14))
    img = base + texture + ribs
    if rng.random() < 0.25:
        py, px = rng.integers(size * 0.2, size * 0.8, size=2)
        radius = rng.uniform(size * 0.05, size * 0.10)
        dist = np.sqrt((yy - py) ** 2 + (xx - px) ** 2)
        img += rng.uniform(0.05, 0.15) * np.exp(-(dist ** 2) / (2 * radius ** 2))
    return img


def _make_pneumonia_image(rng, size=IMG_SIZE):
    """Same base lung field plus 1-3 bright, cloud-like opacity patches."""
    img = _make_normal_image(rng, size)
    yy, xx = np.mgrid[0:size, 0:size]
    n_patches = rng.integers(1, 4)
    for _ in range(n_patches):
        py, px = rng.integers(size * 0.2, size * 0.8, size=2)
        radius = rng.uniform(size * 0.07, size * 0.20)
        dist = np.sqrt((yy - py) ** 2 + (xx - px) ** 2)
        intensity = rng.uniform(0.12, 0.32)
        patch = intensity * np.exp(-(dist ** 2) / (2 * radius ** 2))
        img += patch
    return img


def generate_synthetic_dataset(n_train=1600, n_val=200, n_test=200, seed=42):
    """Returns (train_ds, val_ds, test_ds, class_names) as tf.data.Dataset."""
    rng = np.random.default_rng(seed)

    def make_split(n):
        n_pos = n // 2
        n_neg = n - n_pos
        images, labels = [], []
        for _ in range(n_neg):
            images.append(_make_normal_image(rng))
            labels.append(0)
        for _ in range(n_pos):
            images.append(_make_pneumonia_image(rng))
            labels.append(1)
        images = np.clip(np.array(images, dtype=np.float32), 0, 1)
        images = images[..., np.newaxis]  # add channel dim
        labels = np.array(labels, dtype=np.float32)
        # shuffle
        idx = rng.permutation(n)
        return images[idx], labels[idx]

    x_train, y_train = make_split(n_train)
    x_val, y_val = make_split(n_val)
    x_test, y_test = make_split(n_test)

    class_names = ["NORMAL", "PNEUMONIA"]

    def to_ds(x, y, shuffle=False, batch_size=32):
        ds = tf.data.Dataset.from_tensor_slices((x, y))
        if shuffle:
            ds = ds.shuffle(len(x), seed=seed)
        return ds.batch(batch_size).prefetch(tf.data.AUTOTUNE)

    train_ds = to_ds(x_train, y_train, shuffle=True)
    val_ds = to_ds(x_val, y_val)
    test_ds = to_ds(x_test, y_test)

    return train_ds, val_ds, test_ds, class_names, (x_test, y_test)


def load_real_dataset(data_dir, img_size=IMG_SIZE, batch_size=32, seed=42):
    """
    Load the real Kaggle Chest X-Ray Pneumonia dataset from disk.
    data_dir must contain train/, val/, test/ subfolders (see module docstring).
    """
    train_ds = tf.keras.utils.image_dataset_from_directory(
        f"{data_dir}/train", label_mode="binary", color_mode="grayscale",
        image_size=(img_size, img_size), batch_size=batch_size, seed=seed,
    )
    val_ds = tf.keras.utils.image_dataset_from_directory(
        f"{data_dir}/val", label_mode="binary", color_mode="grayscale",
        image_size=(img_size, img_size), batch_size=batch_size, seed=seed,
    )
    test_ds = tf.keras.utils.image_dataset_from_directory(
        f"{data_dir}/test", label_mode="binary", color_mode="grayscale",
        image_size=(img_size, img_size), batch_size=batch_size, seed=seed, shuffle=False,
    )
    class_names = train_ds.class_names

    normalize = tf.keras.layers.Rescaling(1.0 / 255)
    train_ds = train_ds.map(lambda x, y: (normalize(x), y)).prefetch(tf.data.AUTOTUNE)
    val_ds = val_ds.map(lambda x, y: (normalize(x), y)).prefetch(tf.data.AUTOTUNE)
    test_ds = test_ds.map(lambda x, y: (normalize(x), y)).prefetch(tf.data.AUTOTUNE)

    return train_ds, val_ds, test_ds, class_names, None
