# Pneumonia Detection CNN

## Setup
pip install -r requirements.txt

## Run (synthetic demo dataset — works instantly, no download needed)
python train.py

## Run on the real Kaggle dataset
1. Download "Chest X-Ray Images (Pneumonia)" from Kaggle:
   https://www.kaggle.com/datasets/paultimothymooney/chest-xray-pneumonia
2. Unzip so you have chest_xray/train, chest_xray/val, chest_xray/test
3. Run: python train.py --data_dir chest_xray

Outputs (plots, metrics.json, trained model) are written to ./outputs/
