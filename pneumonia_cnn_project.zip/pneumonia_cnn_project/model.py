"""
model.py
========
CNN architecture for binary pneumonia classification on 64x64 grayscale
chest X-ray images.

Design notes (for the report's Methodology section):
- 3 convolutional blocks, each: Conv2D -> BatchNorm -> ReLU -> MaxPool.
  Filter count doubles each block (32 -> 64 -> 128) so the network learns
  progressively more abstract features (edges -> textures -> opacity blobs)
  while spatial resolution shrinks.
- GlobalAveragePooling2D instead of Flatten+Dense to sharply cut the
  parameter count and reduce overfitting risk on a modest dataset size.
- Dropout(0.3) before the final classifier layer for regularisation.
- Single sigmoid output neuron for binary classification (NORMAL vs
  PNEUMONIA), trained with binary cross-entropy.
"""

import tensorflow as tf
from tensorflow.keras import layers, models


def build_cnn(input_shape=(64, 64, 1)):
    model = models.Sequential([
        layers.Input(shape=input_shape),

        layers.Conv2D(32, 3, padding="same"),
        layers.BatchNormalization(),
        layers.ReLU(),
        layers.MaxPooling2D(),

        layers.Conv2D(64, 3, padding="same"),
        layers.BatchNormalization(),
        layers.ReLU(),
        layers.MaxPooling2D(),

        layers.Conv2D(128, 3, padding="same"),
        layers.BatchNormalization(),
        layers.ReLU(),
        layers.MaxPooling2D(),

        layers.GlobalAveragePooling2D(),
        layers.Dropout(0.3),
        layers.Dense(64, activation="relu"),
        layers.Dense(1, activation="sigmoid"),
    ], name="pneumonia_cnn")

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=8e-4),
        loss="binary_crossentropy",
        metrics=["accuracy", tf.keras.metrics.AUC(name="auc")],
    )
    return model
